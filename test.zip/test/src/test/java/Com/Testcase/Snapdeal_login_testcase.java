package Com.Testcase;

import java.io.IOException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Com.Baseclass.Wrapperclass;
import Com.ExcelUtility.Excel_login;
import Com.Pages.Snapdeal_login;

public class Snapdeal_login_testcase extends Wrapperclass{
	
	
	@BeforeMethod
	public void startup()
	{
		launchApplication("chrome","https://www.snapdeal.com/");
	}
	@Test
	public void Login() throws IOException
	{
		Snapdeal_login sn=new Snapdeal_login(driver);
		Excel_login ab=new Excel_login();
		
		sn.Clicking_icon();
		sn.Clicking_login();
		
			
		
		sn.Entering_email(ab.excel_username(1));
		
	

}
}