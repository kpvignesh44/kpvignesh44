package Com.Pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Com.ExcelUtility.Excel_login;

public class Snapdeal_login {
WebDriver driver;
public Snapdeal_login(WebDriver driver)
{
	this.driver=driver;
}
By Click_icon=By.xpath("//*[@id=\"sdHeader\"]/div[4]/div[2]/div/div[3]/div[3]/div/span[2]/i");
By Click_login=By.xpath("//*[@id=\"sdHeader\"]/div[4]/div[2]/div/div[3]/div[3]/div/div/div[2]/div[2]/span[2]");
By email=By.id("userName");

public void Clicking_icon()
{
	
	driver.findElement(Click_icon).click();
}
public void Clicking_login()
{
	driver.findElement(Click_login).click();
}
public void Entering_email(String user) throws IOException
{
{
			driver.findElement(email).sendKeys(user);
}
}
}
