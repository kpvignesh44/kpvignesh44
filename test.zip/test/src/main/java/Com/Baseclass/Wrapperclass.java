package Com.Baseclass;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Wrapperclass {
protected WebDriver driver;

public void launchApplication(String browser,String url) {
	try
	{if(browser.equalsIgnoreCase("firefox"))
	{
		driver=new FirefoxDriver();
	}
	else if(browser.equalsIgnoreCase("chrome"))	
	{System.setProperty("webdriver.chrome.driver","src//test//resources//Driver//chromedriver.exe");
		driver=new ChromeDriver();
	}
	driver.manage().window().maximize();
	driver.get(url);
	driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	}
catch(Exception e)	
	{
	System.out.println("browser could not be launched");
	}}
public void screenshot(String path) throws IOException 
{
	TakesScreenshot ts=((TakesScreenshot)driver);
	File Source=ts.getScreenshotAs(OutputType.FILE);
	
	FileUtils.copyFile(Source,new File(path));
}
}


